​1) Make the up and down arrow work (up would move the character up, down would move the character down).

2) We're going to set a boundary so the character can only stay within x of 0-200 and y of 0-200.  Your goal is to draw this boundary and have the character move within that region.

3) Change the character to a ninja that seems to walk (we'll provide the images)

4) Have the ninja throw a snowball.  The snowball would travel a certain distance and it would disappear.

5) Throw support for another player.

6) Have the second player also be able to throw a snowball.

7) If the snowball hits another player, have the player loose some health.

8) When the player has zero health, display a message that the player died

9) Instead of the whitebackground, find a way to display nice background with trees, flowers, grass, 
water, etc.

10) Have other people appear in this game, and have your ninja be able to talk to those people.